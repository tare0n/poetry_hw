# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hw']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['do_smth = do_smth:main']}

setup_kwargs = {
    'name': 'hw',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'misha kalinin',
    'author_email': 'msktareo@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
